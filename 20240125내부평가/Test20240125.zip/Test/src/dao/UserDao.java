package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import conn.DBConnection;

public class UserDao {
	public boolean Logincheck(String id, String pw) {
		Connection conn = DBConnection.getConnection();
		int cnt = 0;
		try {
			String sql = "SELECT * FROM testmember WHERE id=? AND pw=?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				cnt = rs.getInt(1);
			}
			rs.close();
			pstmt.close();
			conn.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return cnt==1;
	}
}
